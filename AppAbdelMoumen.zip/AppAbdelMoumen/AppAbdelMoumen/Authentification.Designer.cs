﻿
namespace AppAbdelMoumen
{
    partial class Authentification
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.guna2BorderlessForm1 = new Guna.UI2.WinForms.Guna2BorderlessForm(this.components);
            this.bt_Connexion = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientPanel1 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.guna2GradientPanel2 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.guna2CirclePictureBox1 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.txt_Mail = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel8 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.ch_view = new Guna.UI2.WinForms.Guna2ImageCheckBox();
            this.txt_Password = new Guna.UI2.WinForms.Guna2TextBox();
            this.bt_Close = new Guna.UI2.WinForms.Guna2GradientCircleButton();
            this.Gmail = new System.Windows.Forms.LinkLabel();
            this.guna2HtmlLabel7 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel6 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel5 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel4 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.lb_Message = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2GradientPanel1.SuspendLayout();
            this.guna2GradientPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2BorderlessForm1
            // 
            this.guna2BorderlessForm1.BorderRadius = 20;
            this.guna2BorderlessForm1.ContainerControl = this;
            this.guna2BorderlessForm1.ShadowColor = System.Drawing.Color.Transparent;
            this.guna2BorderlessForm1.TransparentWhileDrag = true;
            // 
            // bt_Connexion
            // 
            this.bt_Connexion.Animated = true;
            this.bt_Connexion.BorderColor = System.Drawing.Color.White;
            this.bt_Connexion.BorderRadius = 20;
            this.bt_Connexion.CheckedState.Parent = this.bt_Connexion;
            this.bt_Connexion.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bt_Connexion.CustomImages.Parent = this.bt_Connexion;
            this.bt_Connexion.FillColor = System.Drawing.Color.RoyalBlue;
            this.bt_Connexion.FillColor2 = System.Drawing.Color.Blue;
            this.bt_Connexion.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.bt_Connexion.ForeColor = System.Drawing.Color.White;
            this.bt_Connexion.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.bt_Connexion.HoverState.FillColor = System.Drawing.Color.Blue;
            this.bt_Connexion.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.bt_Connexion.HoverState.ForeColor = System.Drawing.Color.Lime;
            this.bt_Connexion.HoverState.Parent = this.bt_Connexion;
            this.bt_Connexion.Location = new System.Drawing.Point(51, 352);
            this.bt_Connexion.Name = "bt_Connexion";
            this.bt_Connexion.ShadowDecoration.Parent = this.bt_Connexion;
            this.bt_Connexion.Size = new System.Drawing.Size(146, 42);
            this.bt_Connexion.TabIndex = 2;
            this.bt_Connexion.Text = "Connexion";
            this.bt_Connexion.Click += new System.EventHandler(this.bt_Connexion_Click);
            // 
            // guna2GradientPanel1
            // 
            this.guna2GradientPanel1.Controls.Add(this.guna2GradientPanel2);
            this.guna2GradientPanel1.Controls.Add(this.bt_Close);
            this.guna2GradientPanel1.Controls.Add(this.Gmail);
            this.guna2GradientPanel1.Controls.Add(this.guna2HtmlLabel7);
            this.guna2GradientPanel1.Controls.Add(this.guna2HtmlLabel6);
            this.guna2GradientPanel1.Controls.Add(this.guna2HtmlLabel5);
            this.guna2GradientPanel1.Controls.Add(this.guna2HtmlLabel4);
            this.guna2GradientPanel1.Controls.Add(this.guna2HtmlLabel3);
            this.guna2GradientPanel1.Controls.Add(this.guna2HtmlLabel2);
            this.guna2GradientPanel1.Controls.Add(this.guna2HtmlLabel1);
            this.guna2GradientPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.guna2GradientPanel1.FillColor = System.Drawing.Color.DarkBlue;
            this.guna2GradientPanel1.FillColor2 = System.Drawing.Color.RoyalBlue;
            this.guna2GradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.guna2GradientPanel1.Name = "guna2GradientPanel1";
            this.guna2GradientPanel1.ShadowDecoration.Parent = this.guna2GradientPanel1;
            this.guna2GradientPanel1.Size = new System.Drawing.Size(925, 530);
            this.guna2GradientPanel1.TabIndex = 4;
            // 
            // guna2GradientPanel2
            // 
            this.guna2GradientPanel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientPanel2.BorderRadius = 10;
            this.guna2GradientPanel2.Controls.Add(this.lb_Message);
            this.guna2GradientPanel2.Controls.Add(this.guna2CirclePictureBox1);
            this.guna2GradientPanel2.Controls.Add(this.txt_Mail);
            this.guna2GradientPanel2.Controls.Add(this.guna2HtmlLabel8);
            this.guna2GradientPanel2.Controls.Add(this.ch_view);
            this.guna2GradientPanel2.Controls.Add(this.bt_Connexion);
            this.guna2GradientPanel2.Controls.Add(this.txt_Password);
            this.guna2GradientPanel2.FillColor = System.Drawing.SystemColors.ActiveCaption;
            this.guna2GradientPanel2.FillColor2 = System.Drawing.Color.DarkBlue;
            this.guna2GradientPanel2.Location = new System.Drawing.Point(449, 40);
            this.guna2GradientPanel2.Name = "guna2GradientPanel2";
            this.guna2GradientPanel2.ShadowDecoration.BorderRadius = 10;
            this.guna2GradientPanel2.ShadowDecoration.Color = System.Drawing.Color.White;
            this.guna2GradientPanel2.ShadowDecoration.Parent = this.guna2GradientPanel2;
            this.guna2GradientPanel2.Size = new System.Drawing.Size(401, 457);
            this.guna2GradientPanel2.TabIndex = 12;
            // 
            // guna2CirclePictureBox1
            // 
            this.guna2CirclePictureBox1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.guna2CirclePictureBox1.Image = global::AppAbdelMoumen.Properties.Resources._2754578_128;
            this.guna2CirclePictureBox1.Location = new System.Drawing.Point(107, 12);
            this.guna2CirclePictureBox1.Name = "guna2CirclePictureBox1";
            this.guna2CirclePictureBox1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CirclePictureBox1.ShadowDecoration.Parent = this.guna2CirclePictureBox1;
            this.guna2CirclePictureBox1.Size = new System.Drawing.Size(160, 126);
            this.guna2CirclePictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.guna2CirclePictureBox1.TabIndex = 3;
            this.guna2CirclePictureBox1.TabStop = false;
            this.guna2CirclePictureBox1.UseTransparentBackground = true;
            // 
            // txt_Mail
            // 
            this.txt_Mail.Animated = true;
            this.txt_Mail.BorderColor = System.Drawing.Color.RoyalBlue;
            this.txt_Mail.BorderRadius = 10;
            this.txt_Mail.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_Mail.DefaultText = "";
            this.txt_Mail.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_Mail.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_Mail.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Mail.DisabledState.Parent = this.txt_Mail;
            this.txt_Mail.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Mail.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Mail.FocusedState.Parent = this.txt_Mail;
            this.txt_Mail.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txt_Mail.ForeColor = System.Drawing.Color.RoyalBlue;
            this.txt_Mail.HoverState.BorderColor = System.Drawing.Color.Cyan;
            this.txt_Mail.HoverState.FillColor = System.Drawing.Color.White;
            this.txt_Mail.HoverState.Parent = this.txt_Mail;
            this.txt_Mail.IconLeft = global::AppAbdelMoumen.Properties.Resources.user;
            this.txt_Mail.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.txt_Mail.ImeMode = System.Windows.Forms.ImeMode.Katakana;
            this.txt_Mail.Location = new System.Drawing.Point(51, 192);
            this.txt_Mail.Name = "txt_Mail";
            this.txt_Mail.PasswordChar = '\0';
            this.txt_Mail.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.txt_Mail.PlaceholderText = "Saisir votre mail";
            this.txt_Mail.SelectedText = "";
            this.txt_Mail.ShadowDecoration.Parent = this.txt_Mail;
            this.txt_Mail.Size = new System.Drawing.Size(297, 36);
            this.txt_Mail.TabIndex = 1;
            // 
            // guna2HtmlLabel8
            // 
            this.guna2HtmlLabel8.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel8.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel8.ForeColor = System.Drawing.Color.Gray;
            this.guna2HtmlLabel8.Location = new System.Drawing.Point(331, 435);
            this.guna2HtmlLabel8.Name = "guna2HtmlLabel8";
            this.guna2HtmlLabel8.Size = new System.Drawing.Size(67, 19);
            this.guna2HtmlLabel8.TabIndex = 10;
            this.guna2HtmlLabel8.Text = "Version 1.1";
            // 
            // ch_view
            // 
            this.ch_view.BackColor = System.Drawing.Color.Transparent;
            this.ch_view.CheckedState.Image = global::AppAbdelMoumen.Properties.Resources._2303107_24;
            this.ch_view.CheckedState.Parent = this.ch_view;
            this.ch_view.HoverState.Parent = this.ch_view;
            this.ch_view.Image = global::AppAbdelMoumen.Properties.Resources._2303106_24;
            this.ch_view.IndicateFocus = false;
            this.ch_view.Location = new System.Drawing.Point(314, 284);
            this.ch_view.Name = "ch_view";
            this.ch_view.PressedState.Parent = this.ch_view;
            this.ch_view.Size = new System.Drawing.Size(34, 36);
            this.ch_view.TabIndex = 5;
            this.ch_view.UseTransparentBackground = true;
            this.ch_view.CheckedChanged += new System.EventHandler(this.ch_view_CheckedChanged);
            // 
            // txt_Password
            // 
            this.txt_Password.Animated = true;
            this.txt_Password.BorderColor = System.Drawing.Color.RoyalBlue;
            this.txt_Password.BorderRadius = 10;
            this.txt_Password.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_Password.DefaultText = "";
            this.txt_Password.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_Password.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_Password.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Password.DisabledState.Parent = this.txt_Password;
            this.txt_Password.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Password.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Password.FocusedState.Parent = this.txt_Password;
            this.txt_Password.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txt_Password.ForeColor = System.Drawing.Color.RoyalBlue;
            this.txt_Password.HoverState.BorderColor = System.Drawing.Color.Cyan;
            this.txt_Password.HoverState.Parent = this.txt_Password;
            this.txt_Password.IconLeft = global::AppAbdelMoumen.Properties.Resources.mbrilock_99595;
            this.txt_Password.Location = new System.Drawing.Point(51, 284);
            this.txt_Password.Name = "txt_Password";
            this.txt_Password.PasswordChar = '\0';
            this.txt_Password.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.txt_Password.PlaceholderText = "Saisir votre mot de passe";
            this.txt_Password.SelectedText = "";
            this.txt_Password.ShadowDecoration.Parent = this.txt_Password;
            this.txt_Password.Size = new System.Drawing.Size(297, 36);
            this.txt_Password.TabIndex = 1;
            // 
            // bt_Close
            // 
            this.bt_Close.Animated = true;
            this.bt_Close.BackColor = System.Drawing.Color.Transparent;
            this.bt_Close.CheckedState.Parent = this.bt_Close;
            this.bt_Close.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bt_Close.CustomImages.Parent = this.bt_Close;
            this.bt_Close.FillColor = System.Drawing.Color.RoyalBlue;
            this.bt_Close.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.bt_Close.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_Close.ForeColor = System.Drawing.Color.White;
            this.bt_Close.HoverState.BorderColor = System.Drawing.Color.Red;
            this.bt_Close.HoverState.FillColor = System.Drawing.Color.White;
            this.bt_Close.HoverState.FillColor2 = System.Drawing.Color.Red;
            this.bt_Close.HoverState.ForeColor = System.Drawing.Color.Red;
            this.bt_Close.HoverState.Parent = this.bt_Close;
            this.bt_Close.Location = new System.Drawing.Point(892, 3);
            this.bt_Close.Name = "bt_Close";
            this.bt_Close.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.bt_Close.ShadowDecoration.Parent = this.bt_Close;
            this.bt_Close.Size = new System.Drawing.Size(29, 30);
            this.bt_Close.TabIndex = 11;
            this.bt_Close.Text = "X";
            this.bt_Close.UseTransparentBackground = true;
            this.bt_Close.Click += new System.EventHandler(this.bt_Close_Click);
            // 
            // Gmail
            // 
            this.Gmail.AutoSize = true;
            this.Gmail.BackColor = System.Drawing.Color.Transparent;
            this.Gmail.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.Gmail.LinkColor = System.Drawing.Color.White;
            this.Gmail.Location = new System.Drawing.Point(164, 506);
            this.Gmail.Name = "Gmail";
            this.Gmail.Size = new System.Drawing.Size(69, 13);
            this.Gmail.TabIndex = 7;
            this.Gmail.TabStop = true;
            this.Gmail.Text = "Contact US";
            // 
            // guna2HtmlLabel7
            // 
            this.guna2HtmlLabel7.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel7.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel7.ForeColor = System.Drawing.Color.White;
            this.guna2HtmlLabel7.Location = new System.Drawing.Point(29, 503);
            this.guna2HtmlLabel7.Name = "guna2HtmlLabel7";
            this.guna2HtmlLabel7.Size = new System.Drawing.Size(134, 19);
            this.guna2HtmlLabel7.TabIndex = 6;
            this.guna2HtmlLabel7.Text = "Friends FAFC Software";
            // 
            // guna2HtmlLabel6
            // 
            this.guna2HtmlLabel6.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel6.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel6.ForeColor = System.Drawing.Color.White;
            this.guna2HtmlLabel6.Location = new System.Drawing.Point(29, 488);
            this.guna2HtmlLabel6.Name = "guna2HtmlLabel6";
            this.guna2HtmlLabel6.Size = new System.Drawing.Size(69, 19);
            this.guna2HtmlLabel6.TabIndex = 5;
            this.guna2HtmlLabel6.Text = "Devlop By :";
            // 
            // guna2HtmlLabel5
            // 
            this.guna2HtmlLabel5.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel5.Font = new System.Drawing.Font("Century Gothic", 17F);
            this.guna2HtmlLabel5.ForeColor = System.Drawing.Color.White;
            this.guna2HtmlLabel5.Location = new System.Drawing.Point(29, 289);
            this.guna2HtmlLabel5.Name = "guna2HtmlLabel5";
            this.guna2HtmlLabel5.Size = new System.Drawing.Size(283, 29);
            this.guna2HtmlLabel5.TabIndex = 4;
            this.guna2HtmlLabel5.Text = "pour gestion les données";
            // 
            // guna2HtmlLabel4
            // 
            this.guna2HtmlLabel4.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel4.Font = new System.Drawing.Font("Century Gothic", 17F);
            this.guna2HtmlLabel4.ForeColor = System.Drawing.Color.White;
            this.guna2HtmlLabel4.Location = new System.Drawing.Point(29, 256);
            this.guna2HtmlLabel4.Name = "guna2HtmlLabel4";
            this.guna2HtmlLabel4.Size = new System.Drawing.Size(170, 29);
            this.guna2HtmlLabel4.TabIndex = 3;
            this.guna2HtmlLabel4.Text = "à l\'application";
            // 
            // guna2HtmlLabel3
            // 
            this.guna2HtmlLabel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel3.Font = new System.Drawing.Font("Century Gothic", 17F);
            this.guna2HtmlLabel3.ForeColor = System.Drawing.Color.White;
            this.guna2HtmlLabel3.Location = new System.Drawing.Point(29, 223);
            this.guna2HtmlLabel3.Name = "guna2HtmlLabel3";
            this.guna2HtmlLabel3.Size = new System.Drawing.Size(109, 29);
            this.guna2HtmlLabel3.TabIndex = 2;
            this.guna2HtmlLabel3.Text = "Bienvenu \r\n";
            // 
            // guna2HtmlLabel2
            // 
            this.guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel2.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel2.ForeColor = System.Drawing.Color.White;
            this.guna2HtmlLabel2.Location = new System.Drawing.Point(334, 75);
            this.guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            this.guna2HtmlLabel2.Size = new System.Drawing.Size(61, 25);
            this.guna2HtmlLabel2.TabIndex = 1;
            this.guna2HtmlLabel2.Text = "Oujda";
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Century Gothic", 25.25F, System.Drawing.FontStyle.Bold);
            this.guna2HtmlLabel1.ForeColor = System.Drawing.Color.White;
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(34, 40);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(361, 42);
            this.guna2HtmlLabel1.TabIndex = 0;
            this.guna2HtmlLabel1.Text = "Lycée Abdelmoumen";
            // 
            // lb_Message
            // 
            this.lb_Message.BackColor = System.Drawing.Color.Transparent;
            this.lb_Message.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Message.ForeColor = System.Drawing.Color.Red;
            this.lb_Message.Location = new System.Drawing.Point(51, 327);
            this.lb_Message.Name = "lb_Message";
            this.lb_Message.Size = new System.Drawing.Size(3, 2);
            this.lb_Message.TabIndex = 13;
            // 
            // Authentification
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(925, 530);
            this.Controls.Add(this.guna2GradientPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Authentification";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.guna2GradientPanel1.ResumeLayout(false);
            this.guna2GradientPanel1.PerformLayout();
            this.guna2GradientPanel2.ResumeLayout(false);
            this.guna2GradientPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2BorderlessForm guna2BorderlessForm1;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox1;
        private Guna.UI2.WinForms.Guna2GradientButton bt_Connexion;
        private Guna.UI2.WinForms.Guna2TextBox txt_Mail;
        private Guna.UI2.WinForms.Guna2TextBox txt_Password;
        private Guna.UI2.WinForms.Guna2ImageCheckBox ch_view;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel7;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel6;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel5;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel4;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel8;
        private System.Windows.Forms.LinkLabel Gmail;
        private Guna.UI2.WinForms.Guna2GradientCircleButton bt_Close;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel2;
        private Guna.UI2.WinForms.Guna2HtmlLabel lb_Message;
    }
}

