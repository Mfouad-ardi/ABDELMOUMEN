﻿
namespace AppAbdelMoumen
{
    partial class Enseignanats
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cb_Nom = new Guna.UI2.WinForms.Guna2ComboBox();
            this.guna2ShadowPanel3 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.bt_Reinitialiser = new Guna.UI2.WinForms.Guna2GradientButton();
            this.label12 = new System.Windows.Forms.Label();
            this.lb_Mail = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.bt_Supprimer = new Guna.UI2.WinForms.Guna2GradientButton();
            this.bt_Ajouter = new Guna.UI2.WinForms.Guna2GradientButton();
            this.bt_Modifier = new Guna.UI2.WinForms.Guna2GradientButton();
            this.txt_Prenom = new Guna.UI2.WinForms.Guna2TextBox();
            this.cb_Matiére = new Guna.UI2.WinForms.Guna2ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.guna2ShadowPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // cb_Nom
            // 
            this.cb_Nom.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cb_Nom.Animated = true;
            this.cb_Nom.BackColor = System.Drawing.Color.Transparent;
            this.cb_Nom.BorderRadius = 15;
            this.cb_Nom.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cb_Nom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_Nom.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cb_Nom.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cb_Nom.FocusedState.Parent = this.cb_Nom;
            this.cb_Nom.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cb_Nom.ForeColor = System.Drawing.Color.Blue;
            this.cb_Nom.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.cb_Nom.HoverState.Parent = this.cb_Nom;
            this.cb_Nom.ItemHeight = 30;
            this.cb_Nom.ItemsAppearance.Parent = this.cb_Nom;
            this.cb_Nom.Location = new System.Drawing.Point(111, 87);
            this.cb_Nom.Name = "cb_Nom";
            this.cb_Nom.ShadowDecoration.Parent = this.cb_Nom;
            this.cb_Nom.Size = new System.Drawing.Size(259, 36);
            this.cb_Nom.TabIndex = 12;
            // 
            // guna2ShadowPanel3
            // 
            this.guna2ShadowPanel3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.guna2ShadowPanel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel3.Controls.Add(this.cb_Matiére);
            this.guna2ShadowPanel3.Controls.Add(this.label2);
            this.guna2ShadowPanel3.Controls.Add(this.bt_Reinitialiser);
            this.guna2ShadowPanel3.Controls.Add(this.cb_Nom);
            this.guna2ShadowPanel3.Controls.Add(this.label12);
            this.guna2ShadowPanel3.Controls.Add(this.lb_Mail);
            this.guna2ShadowPanel3.Controls.Add(this.label1);
            this.guna2ShadowPanel3.Controls.Add(this.label9);
            this.guna2ShadowPanel3.Controls.Add(this.bt_Supprimer);
            this.guna2ShadowPanel3.Controls.Add(this.bt_Ajouter);
            this.guna2ShadowPanel3.Controls.Add(this.bt_Modifier);
            this.guna2ShadowPanel3.Controls.Add(this.txt_Prenom);
            this.guna2ShadowPanel3.FillColor = System.Drawing.Color.Blue;
            this.guna2ShadowPanel3.Location = new System.Drawing.Point(36, 157);
            this.guna2ShadowPanel3.Name = "guna2ShadowPanel3";
            this.guna2ShadowPanel3.ShadowColor = System.Drawing.Color.Black;
            this.guna2ShadowPanel3.ShadowShift = 12;
            this.guna2ShadowPanel3.Size = new System.Drawing.Size(868, 341);
            this.guna2ShadowPanel3.TabIndex = 15;
            // 
            // bt_Reinitialiser
            // 
            this.bt_Reinitialiser.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bt_Reinitialiser.BorderRadius = 20;
            this.bt_Reinitialiser.CheckedState.Parent = this.bt_Reinitialiser;
            this.bt_Reinitialiser.CustomImages.Parent = this.bt_Reinitialiser;
            this.bt_Reinitialiser.FillColor = System.Drawing.Color.Navy;
            this.bt_Reinitialiser.FillColor2 = System.Drawing.Color.DodgerBlue;
            this.bt_Reinitialiser.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bt_Reinitialiser.ForeColor = System.Drawing.Color.White;
            this.bt_Reinitialiser.HoverState.BorderColor = System.Drawing.Color.Black;
            this.bt_Reinitialiser.HoverState.FillColor = System.Drawing.Color.Navy;
            this.bt_Reinitialiser.HoverState.FillColor2 = System.Drawing.Color.Navy;
            this.bt_Reinitialiser.HoverState.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bt_Reinitialiser.HoverState.ForeColor = System.Drawing.Color.White;
            this.bt_Reinitialiser.HoverState.Parent = this.bt_Reinitialiser;
            this.bt_Reinitialiser.Location = new System.Drawing.Point(582, 236);
            this.bt_Reinitialiser.Name = "bt_Reinitialiser";
            this.bt_Reinitialiser.ShadowDecoration.Parent = this.bt_Reinitialiser;
            this.bt_Reinitialiser.Size = new System.Drawing.Size(166, 39);
            this.bt_Reinitialiser.TabIndex = 8;
            this.bt_Reinitialiser.Text = "Réinitialiser";
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(105, 166);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(51, 17);
            this.label12.TabIndex = 15;
            this.label12.Text = "Email :";
            // 
            // lb_Mail
            // 
            this.lb_Mail.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lb_Mail.AutoSize = true;
            this.lb_Mail.ForeColor = System.Drawing.Color.White;
            this.lb_Mail.Location = new System.Drawing.Point(172, 166);
            this.lb_Mail.Name = "lb_Mail";
            this.lb_Mail.Size = new System.Drawing.Size(236, 17);
            this.lb_Mail.TabIndex = 14;
            this.lb_Mail.Text = "Nom.Prenom@Abdelmoumen.com";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(490, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 17);
            this.label1.TabIndex = 9;
            this.label1.Text = "Prénom :";
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(108, 60);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(48, 17);
            this.label9.TabIndex = 9;
            this.label9.Text = "Nom :";
            // 
            // bt_Supprimer
            // 
            this.bt_Supprimer.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bt_Supprimer.BorderRadius = 20;
            this.bt_Supprimer.CheckedState.Parent = this.bt_Supprimer;
            this.bt_Supprimer.CustomImages.Parent = this.bt_Supprimer;
            this.bt_Supprimer.FillColor = System.Drawing.Color.Navy;
            this.bt_Supprimer.FillColor2 = System.Drawing.Color.DodgerBlue;
            this.bt_Supprimer.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bt_Supprimer.ForeColor = System.Drawing.Color.White;
            this.bt_Supprimer.HoverState.BorderColor = System.Drawing.Color.Black;
            this.bt_Supprimer.HoverState.FillColor = System.Drawing.Color.Navy;
            this.bt_Supprimer.HoverState.FillColor2 = System.Drawing.Color.Navy;
            this.bt_Supprimer.HoverState.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bt_Supprimer.HoverState.ForeColor = System.Drawing.Color.White;
            this.bt_Supprimer.HoverState.Parent = this.bt_Supprimer;
            this.bt_Supprimer.Location = new System.Drawing.Point(440, 236);
            this.bt_Supprimer.Name = "bt_Supprimer";
            this.bt_Supprimer.ShadowDecoration.Parent = this.bt_Supprimer;
            this.bt_Supprimer.Size = new System.Drawing.Size(118, 39);
            this.bt_Supprimer.TabIndex = 8;
            this.bt_Supprimer.Text = "Supprimer";
            // 
            // bt_Ajouter
            // 
            this.bt_Ajouter.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bt_Ajouter.BorderRadius = 20;
            this.bt_Ajouter.CheckedState.Parent = this.bt_Ajouter;
            this.bt_Ajouter.CustomImages.Parent = this.bt_Ajouter;
            this.bt_Ajouter.FillColor = System.Drawing.Color.Navy;
            this.bt_Ajouter.FillColor2 = System.Drawing.Color.DodgerBlue;
            this.bt_Ajouter.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bt_Ajouter.ForeColor = System.Drawing.Color.White;
            this.bt_Ajouter.HoverState.BorderColor = System.Drawing.Color.Black;
            this.bt_Ajouter.HoverState.FillColor = System.Drawing.Color.Navy;
            this.bt_Ajouter.HoverState.FillColor2 = System.Drawing.Color.Navy;
            this.bt_Ajouter.HoverState.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bt_Ajouter.HoverState.ForeColor = System.Drawing.Color.White;
            this.bt_Ajouter.HoverState.Parent = this.bt_Ajouter;
            this.bt_Ajouter.Location = new System.Drawing.Point(111, 236);
            this.bt_Ajouter.Name = "bt_Ajouter";
            this.bt_Ajouter.ShadowDecoration.Parent = this.bt_Ajouter;
            this.bt_Ajouter.Size = new System.Drawing.Size(118, 39);
            this.bt_Ajouter.TabIndex = 8;
            this.bt_Ajouter.Text = "Ajouter";
            // 
            // bt_Modifier
            // 
            this.bt_Modifier.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bt_Modifier.BorderRadius = 20;
            this.bt_Modifier.CheckedState.Parent = this.bt_Modifier;
            this.bt_Modifier.CustomImages.Parent = this.bt_Modifier;
            this.bt_Modifier.FillColor = System.Drawing.Color.Navy;
            this.bt_Modifier.FillColor2 = System.Drawing.Color.DodgerBlue;
            this.bt_Modifier.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bt_Modifier.ForeColor = System.Drawing.Color.White;
            this.bt_Modifier.HoverState.BorderColor = System.Drawing.Color.Black;
            this.bt_Modifier.HoverState.FillColor = System.Drawing.Color.Navy;
            this.bt_Modifier.HoverState.FillColor2 = System.Drawing.Color.Navy;
            this.bt_Modifier.HoverState.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bt_Modifier.HoverState.ForeColor = System.Drawing.Color.White;
            this.bt_Modifier.HoverState.Parent = this.bt_Modifier;
            this.bt_Modifier.Location = new System.Drawing.Point(279, 236);
            this.bt_Modifier.Name = "bt_Modifier";
            this.bt_Modifier.ShadowDecoration.Parent = this.bt_Modifier;
            this.bt_Modifier.Size = new System.Drawing.Size(118, 39);
            this.bt_Modifier.TabIndex = 8;
            this.bt_Modifier.Text = "Modifier";
            // 
            // txt_Prenom
            // 
            this.txt_Prenom.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_Prenom.Animated = true;
            this.txt_Prenom.BorderRadius = 15;
            this.txt_Prenom.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_Prenom.DefaultText = "";
            this.txt_Prenom.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_Prenom.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_Prenom.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Prenom.DisabledState.Parent = this.txt_Prenom;
            this.txt_Prenom.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Prenom.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Prenom.FocusedState.Parent = this.txt_Prenom;
            this.txt_Prenom.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txt_Prenom.ForeColor = System.Drawing.Color.Blue;
            this.txt_Prenom.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.txt_Prenom.HoverState.Parent = this.txt_Prenom;
            this.txt_Prenom.Location = new System.Drawing.Point(494, 87);
            this.txt_Prenom.Name = "txt_Prenom";
            this.txt_Prenom.PasswordChar = '\0';
            this.txt_Prenom.PlaceholderForeColor = System.Drawing.Color.CornflowerBlue;
            this.txt_Prenom.PlaceholderText = "Saisir le prénom";
            this.txt_Prenom.SelectedText = "";
            this.txt_Prenom.ShadowDecoration.Parent = this.txt_Prenom;
            this.txt_Prenom.Size = new System.Drawing.Size(252, 36);
            this.txt_Prenom.TabIndex = 7;
            // 
            // cb_Matiére
            // 
            this.cb_Matiére.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cb_Matiére.Animated = true;
            this.cb_Matiére.BackColor = System.Drawing.Color.Transparent;
            this.cb_Matiére.BorderRadius = 15;
            this.cb_Matiére.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cb_Matiére.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_Matiére.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cb_Matiére.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cb_Matiére.FocusedState.Parent = this.cb_Matiére;
            this.cb_Matiére.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cb_Matiére.ForeColor = System.Drawing.Color.Blue;
            this.cb_Matiére.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.cb_Matiére.HoverState.Parent = this.cb_Matiére;
            this.cb_Matiére.ItemHeight = 30;
            this.cb_Matiére.ItemsAppearance.Parent = this.cb_Matiére;
            this.cb_Matiére.Location = new System.Drawing.Point(494, 166);
            this.cb_Matiére.Name = "cb_Matiére";
            this.cb_Matiére.ShadowDecoration.Parent = this.cb_Matiére;
            this.cb_Matiére.Size = new System.Drawing.Size(259, 36);
            this.cb_Matiére.TabIndex = 17;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(491, 139);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 17);
            this.label2.TabIndex = 16;
            this.label2.Text = "Matiére :";
            // 
            // Enseignanats
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(935, 681);
            this.Controls.Add(this.guna2ShadowPanel3);
            this.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Enseignanats";
            this.Text = "Enseignanats";
            this.guna2ShadowPanel3.ResumeLayout(false);
            this.guna2ShadowPanel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2ComboBox cb_Nom;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel3;
        private Guna.UI2.WinForms.Guna2GradientButton bt_Reinitialiser;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lb_Mail;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label9;
        private Guna.UI2.WinForms.Guna2GradientButton bt_Supprimer;
        private Guna.UI2.WinForms.Guna2GradientButton bt_Ajouter;
        private Guna.UI2.WinForms.Guna2GradientButton bt_Modifier;
        private Guna.UI2.WinForms.Guna2TextBox txt_Prenom;
        private Guna.UI2.WinForms.Guna2ComboBox cb_Matiére;
        private System.Windows.Forms.Label label2;
    }
}