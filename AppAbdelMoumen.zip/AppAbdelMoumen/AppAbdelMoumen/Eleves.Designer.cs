﻿
namespace AppAbdelMoumen
{
    partial class Eleves
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.guna2ShadowPanel3 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.bt_Reinitialiser = new Guna.UI2.WinForms.Guna2GradientButton();
            this.label12 = new System.Windows.Forms.Label();
            this.lb_Mail = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_Numero = new Guna.UI2.WinForms.Guna2TextBox();
            this.cb_Niveau = new Guna.UI2.WinForms.Guna2ComboBox();
            this.cb_AjtClasse = new Guna.UI2.WinForms.Guna2ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.bt_Supprimer = new Guna.UI2.WinForms.Guna2GradientButton();
            this.bt_Ajouter = new Guna.UI2.WinForms.Guna2GradientButton();
            this.bt_Modifier = new Guna.UI2.WinForms.Guna2GradientButton();
            this.bt_Imprimer = new Guna.UI2.WinForms.Guna2GradientButton();
            this.txt_Massar = new Guna.UI2.WinForms.Guna2TextBox();
            this.txt_Prenom = new Guna.UI2.WinForms.Guna2TextBox();
            this.txt_Nom = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2ShadowPanel2 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_NomSearch = new Guna.UI2.WinForms.Guna2TextBox();
            this.DGV_Result = new Guna.UI2.WinForms.Guna2DataGridView();
            this.cb_classe = new Guna.UI2.WinForms.Guna2ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.guna2ShadowPanel3.SuspendLayout();
            this.guna2ShadowPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Result)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2ShadowPanel3
            // 
            this.guna2ShadowPanel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ShadowPanel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel3.Controls.Add(this.bt_Reinitialiser);
            this.guna2ShadowPanel3.Controls.Add(this.label12);
            this.guna2ShadowPanel3.Controls.Add(this.lb_Mail);
            this.guna2ShadowPanel3.Controls.Add(this.label6);
            this.guna2ShadowPanel3.Controls.Add(this.txt_Numero);
            this.guna2ShadowPanel3.Controls.Add(this.cb_Niveau);
            this.guna2ShadowPanel3.Controls.Add(this.cb_AjtClasse);
            this.guna2ShadowPanel3.Controls.Add(this.label2);
            this.guna2ShadowPanel3.Controls.Add(this.label3);
            this.guna2ShadowPanel3.Controls.Add(this.label10);
            this.guna2ShadowPanel3.Controls.Add(this.label1);
            this.guna2ShadowPanel3.Controls.Add(this.label9);
            this.guna2ShadowPanel3.Controls.Add(this.bt_Supprimer);
            this.guna2ShadowPanel3.Controls.Add(this.bt_Ajouter);
            this.guna2ShadowPanel3.Controls.Add(this.bt_Modifier);
            this.guna2ShadowPanel3.Controls.Add(this.bt_Imprimer);
            this.guna2ShadowPanel3.Controls.Add(this.txt_Massar);
            this.guna2ShadowPanel3.Controls.Add(this.txt_Prenom);
            this.guna2ShadowPanel3.Controls.Add(this.txt_Nom);
            this.guna2ShadowPanel3.FillColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel3.Location = new System.Drawing.Point(3, 0);
            this.guna2ShadowPanel3.Name = "guna2ShadowPanel3";
            this.guna2ShadowPanel3.ShadowColor = System.Drawing.Color.Black;
            this.guna2ShadowPanel3.ShadowShift = 12;
            this.guna2ShadowPanel3.Size = new System.Drawing.Size(868, 341);
            this.guna2ShadowPanel3.TabIndex = 12;
            // 
            // bt_Reinitialiser
            // 
            this.bt_Reinitialiser.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bt_Reinitialiser.BorderRadius = 20;
            this.bt_Reinitialiser.CheckedState.Parent = this.bt_Reinitialiser;
            this.bt_Reinitialiser.CustomImages.Parent = this.bt_Reinitialiser;
            this.bt_Reinitialiser.FillColor = System.Drawing.Color.Navy;
            this.bt_Reinitialiser.FillColor2 = System.Drawing.Color.DodgerBlue;
            this.bt_Reinitialiser.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bt_Reinitialiser.ForeColor = System.Drawing.Color.White;
            this.bt_Reinitialiser.HoverState.BorderColor = System.Drawing.Color.Black;
            this.bt_Reinitialiser.HoverState.FillColor = System.Drawing.Color.Navy;
            this.bt_Reinitialiser.HoverState.FillColor2 = System.Drawing.Color.Navy;
            this.bt_Reinitialiser.HoverState.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bt_Reinitialiser.HoverState.ForeColor = System.Drawing.Color.White;
            this.bt_Reinitialiser.HoverState.Parent = this.bt_Reinitialiser;
            this.bt_Reinitialiser.Location = new System.Drawing.Point(722, 275);
            this.bt_Reinitialiser.Name = "bt_Reinitialiser";
            this.bt_Reinitialiser.ShadowDecoration.Parent = this.bt_Reinitialiser;
            this.bt_Reinitialiser.Size = new System.Drawing.Size(118, 39);
            this.bt_Reinitialiser.TabIndex = 8;
            this.bt_Reinitialiser.Text = "Réinitialiser";
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(45, 298);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(51, 17);
            this.label12.TabIndex = 15;
            this.label12.Text = "Email :";
            // 
            // lb_Mail
            // 
            this.lb_Mail.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lb_Mail.AutoSize = true;
            this.lb_Mail.ForeColor = System.Drawing.Color.White;
            this.lb_Mail.Location = new System.Drawing.Point(112, 298);
            this.lb_Mail.Name = "lb_Mail";
            this.lb_Mail.Size = new System.Drawing.Size(236, 17);
            this.lb_Mail.TabIndex = 14;
            this.lb_Mail.Text = "Nom.Prenom@Abdelmoumen.com";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(40, 38);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 17);
            this.label6.TabIndex = 13;
            this.label6.Text = "Numéro :";
            // 
            // txt_Numero
            // 
            this.txt_Numero.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_Numero.Animated = true;
            this.txt_Numero.BorderRadius = 15;
            this.txt_Numero.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_Numero.DefaultText = "";
            this.txt_Numero.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_Numero.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_Numero.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Numero.DisabledState.Parent = this.txt_Numero;
            this.txt_Numero.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Numero.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Numero.FocusedState.Parent = this.txt_Numero;
            this.txt_Numero.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txt_Numero.ForeColor = System.Drawing.Color.Blue;
            this.txt_Numero.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.txt_Numero.HoverState.Parent = this.txt_Numero;
            this.txt_Numero.Location = new System.Drawing.Point(41, 64);
            this.txt_Numero.Name = "txt_Numero";
            this.txt_Numero.PasswordChar = '\0';
            this.txt_Numero.PlaceholderForeColor = System.Drawing.Color.CornflowerBlue;
            this.txt_Numero.PlaceholderText = "Saisir Le numéro";
            this.txt_Numero.SelectedText = "";
            this.txt_Numero.ShadowDecoration.Parent = this.txt_Numero;
            this.txt_Numero.Size = new System.Drawing.Size(252, 36);
            this.txt_Numero.TabIndex = 12;
            // 
            // cb_Niveau
            // 
            this.cb_Niveau.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cb_Niveau.Animated = true;
            this.cb_Niveau.BackColor = System.Drawing.Color.Transparent;
            this.cb_Niveau.BorderRadius = 15;
            this.cb_Niveau.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cb_Niveau.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_Niveau.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cb_Niveau.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cb_Niveau.FocusedState.Parent = this.cb_Niveau;
            this.cb_Niveau.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cb_Niveau.ForeColor = System.Drawing.Color.Blue;
            this.cb_Niveau.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.cb_Niveau.HoverState.Parent = this.cb_Niveau;
            this.cb_Niveau.ItemHeight = 30;
            this.cb_Niveau.ItemsAppearance.Parent = this.cb_Niveau;
            this.cb_Niveau.Location = new System.Drawing.Point(40, 242);
            this.cb_Niveau.Name = "cb_Niveau";
            this.cb_Niveau.ShadowDecoration.Parent = this.cb_Niveau;
            this.cb_Niveau.Size = new System.Drawing.Size(254, 36);
            this.cb_Niveau.TabIndex = 11;
            // 
            // cb_AjtClasse
            // 
            this.cb_AjtClasse.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cb_AjtClasse.Animated = true;
            this.cb_AjtClasse.BackColor = System.Drawing.Color.Transparent;
            this.cb_AjtClasse.BorderRadius = 15;
            this.cb_AjtClasse.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cb_AjtClasse.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_AjtClasse.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cb_AjtClasse.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cb_AjtClasse.FocusedState.Parent = this.cb_AjtClasse;
            this.cb_AjtClasse.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cb_AjtClasse.ForeColor = System.Drawing.Color.Blue;
            this.cb_AjtClasse.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.cb_AjtClasse.HoverState.Parent = this.cb_AjtClasse;
            this.cb_AjtClasse.ItemHeight = 30;
            this.cb_AjtClasse.ItemsAppearance.Parent = this.cb_AjtClasse;
            this.cb_AjtClasse.Location = new System.Drawing.Point(423, 242);
            this.cb_AjtClasse.Name = "cb_AjtClasse";
            this.cb_AjtClasse.ShadowDecoration.Parent = this.cb_AjtClasse;
            this.cb_AjtClasse.Size = new System.Drawing.Size(254, 36);
            this.cb_AjtClasse.TabIndex = 11;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(424, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 17);
            this.label2.TabIndex = 10;
            this.label2.Text = "Massar :";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(422, 222);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 17);
            this.label3.TabIndex = 10;
            this.label3.Text = "Classe :";
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(45, 216);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(62, 17);
            this.label10.TabIndex = 10;
            this.label10.Text = "Niveau :";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(424, 123);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 17);
            this.label1.TabIndex = 9;
            this.label1.Text = "Prénom :";
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(42, 123);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(48, 17);
            this.label9.TabIndex = 9;
            this.label9.Text = "Nom :";
            // 
            // bt_Supprimer
            // 
            this.bt_Supprimer.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bt_Supprimer.BorderRadius = 20;
            this.bt_Supprimer.CheckedState.Parent = this.bt_Supprimer;
            this.bt_Supprimer.CustomImages.Parent = this.bt_Supprimer;
            this.bt_Supprimer.FillColor = System.Drawing.Color.Navy;
            this.bt_Supprimer.FillColor2 = System.Drawing.Color.DodgerBlue;
            this.bt_Supprimer.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bt_Supprimer.ForeColor = System.Drawing.Color.White;
            this.bt_Supprimer.HoverState.BorderColor = System.Drawing.Color.Black;
            this.bt_Supprimer.HoverState.FillColor = System.Drawing.Color.Navy;
            this.bt_Supprimer.HoverState.FillColor2 = System.Drawing.Color.Navy;
            this.bt_Supprimer.HoverState.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bt_Supprimer.HoverState.ForeColor = System.Drawing.Color.White;
            this.bt_Supprimer.HoverState.Parent = this.bt_Supprimer;
            this.bt_Supprimer.Location = new System.Drawing.Point(722, 154);
            this.bt_Supprimer.Name = "bt_Supprimer";
            this.bt_Supprimer.ShadowDecoration.Parent = this.bt_Supprimer;
            this.bt_Supprimer.Size = new System.Drawing.Size(118, 39);
            this.bt_Supprimer.TabIndex = 8;
            this.bt_Supprimer.Text = "Supprimer";
            // 
            // bt_Ajouter
            // 
            this.bt_Ajouter.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bt_Ajouter.BorderRadius = 20;
            this.bt_Ajouter.CheckedState.Parent = this.bt_Ajouter;
            this.bt_Ajouter.CustomImages.Parent = this.bt_Ajouter;
            this.bt_Ajouter.FillColor = System.Drawing.Color.Navy;
            this.bt_Ajouter.FillColor2 = System.Drawing.Color.DodgerBlue;
            this.bt_Ajouter.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bt_Ajouter.ForeColor = System.Drawing.Color.White;
            this.bt_Ajouter.HoverState.BorderColor = System.Drawing.Color.Black;
            this.bt_Ajouter.HoverState.FillColor = System.Drawing.Color.Navy;
            this.bt_Ajouter.HoverState.FillColor2 = System.Drawing.Color.Navy;
            this.bt_Ajouter.HoverState.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bt_Ajouter.HoverState.ForeColor = System.Drawing.Color.White;
            this.bt_Ajouter.HoverState.Parent = this.bt_Ajouter;
            this.bt_Ajouter.Location = new System.Drawing.Point(722, 32);
            this.bt_Ajouter.Name = "bt_Ajouter";
            this.bt_Ajouter.ShadowDecoration.Parent = this.bt_Ajouter;
            this.bt_Ajouter.Size = new System.Drawing.Size(118, 39);
            this.bt_Ajouter.TabIndex = 8;
            this.bt_Ajouter.Text = "Ajouter";
            // 
            // bt_Modifier
            // 
            this.bt_Modifier.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bt_Modifier.BorderRadius = 20;
            this.bt_Modifier.CheckedState.Parent = this.bt_Modifier;
            this.bt_Modifier.CustomImages.Parent = this.bt_Modifier;
            this.bt_Modifier.FillColor = System.Drawing.Color.Navy;
            this.bt_Modifier.FillColor2 = System.Drawing.Color.DodgerBlue;
            this.bt_Modifier.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bt_Modifier.ForeColor = System.Drawing.Color.White;
            this.bt_Modifier.HoverState.BorderColor = System.Drawing.Color.Black;
            this.bt_Modifier.HoverState.FillColor = System.Drawing.Color.Navy;
            this.bt_Modifier.HoverState.FillColor2 = System.Drawing.Color.Navy;
            this.bt_Modifier.HoverState.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bt_Modifier.HoverState.ForeColor = System.Drawing.Color.White;
            this.bt_Modifier.HoverState.Parent = this.bt_Modifier;
            this.bt_Modifier.Location = new System.Drawing.Point(722, 94);
            this.bt_Modifier.Name = "bt_Modifier";
            this.bt_Modifier.ShadowDecoration.Parent = this.bt_Modifier;
            this.bt_Modifier.Size = new System.Drawing.Size(118, 39);
            this.bt_Modifier.TabIndex = 8;
            this.bt_Modifier.Text = "Modifier";
            // 
            // bt_Imprimer
            // 
            this.bt_Imprimer.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bt_Imprimer.BorderRadius = 20;
            this.bt_Imprimer.CheckedState.Parent = this.bt_Imprimer;
            this.bt_Imprimer.CustomImages.Parent = this.bt_Imprimer;
            this.bt_Imprimer.FillColor = System.Drawing.Color.Navy;
            this.bt_Imprimer.FillColor2 = System.Drawing.Color.DodgerBlue;
            this.bt_Imprimer.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bt_Imprimer.ForeColor = System.Drawing.Color.White;
            this.bt_Imprimer.HoverState.BorderColor = System.Drawing.Color.Black;
            this.bt_Imprimer.HoverState.FillColor = System.Drawing.Color.Navy;
            this.bt_Imprimer.HoverState.FillColor2 = System.Drawing.Color.Navy;
            this.bt_Imprimer.HoverState.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bt_Imprimer.HoverState.ForeColor = System.Drawing.Color.White;
            this.bt_Imprimer.HoverState.Parent = this.bt_Imprimer;
            this.bt_Imprimer.Location = new System.Drawing.Point(722, 216);
            this.bt_Imprimer.Name = "bt_Imprimer";
            this.bt_Imprimer.ShadowDecoration.Parent = this.bt_Imprimer;
            this.bt_Imprimer.Size = new System.Drawing.Size(118, 39);
            this.bt_Imprimer.TabIndex = 8;
            this.bt_Imprimer.Text = "Imprimer";
            // 
            // txt_Massar
            // 
            this.txt_Massar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_Massar.Animated = true;
            this.txt_Massar.BorderRadius = 15;
            this.txt_Massar.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_Massar.DefaultText = "";
            this.txt_Massar.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_Massar.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_Massar.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Massar.DisabledState.Parent = this.txt_Massar;
            this.txt_Massar.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Massar.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Massar.FocusedState.Parent = this.txt_Massar;
            this.txt_Massar.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txt_Massar.ForeColor = System.Drawing.Color.Blue;
            this.txt_Massar.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.txt_Massar.HoverState.Parent = this.txt_Massar;
            this.txt_Massar.Location = new System.Drawing.Point(424, 64);
            this.txt_Massar.Name = "txt_Massar";
            this.txt_Massar.PasswordChar = '\0';
            this.txt_Massar.PlaceholderForeColor = System.Drawing.Color.CornflowerBlue;
            this.txt_Massar.PlaceholderText = "Saisir le code MASSAR";
            this.txt_Massar.SelectedText = "";
            this.txt_Massar.ShadowDecoration.Parent = this.txt_Massar;
            this.txt_Massar.Size = new System.Drawing.Size(252, 36);
            this.txt_Massar.TabIndex = 6;
            // 
            // txt_Prenom
            // 
            this.txt_Prenom.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_Prenom.Animated = true;
            this.txt_Prenom.BorderRadius = 15;
            this.txt_Prenom.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_Prenom.DefaultText = "";
            this.txt_Prenom.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_Prenom.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_Prenom.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Prenom.DisabledState.Parent = this.txt_Prenom;
            this.txt_Prenom.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Prenom.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Prenom.FocusedState.Parent = this.txt_Prenom;
            this.txt_Prenom.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txt_Prenom.ForeColor = System.Drawing.Color.Blue;
            this.txt_Prenom.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.txt_Prenom.HoverState.Parent = this.txt_Prenom;
            this.txt_Prenom.Location = new System.Drawing.Point(424, 153);
            this.txt_Prenom.Name = "txt_Prenom";
            this.txt_Prenom.PasswordChar = '\0';
            this.txt_Prenom.PlaceholderForeColor = System.Drawing.Color.CornflowerBlue;
            this.txt_Prenom.PlaceholderText = "Saisir le prénom";
            this.txt_Prenom.SelectedText = "";
            this.txt_Prenom.ShadowDecoration.Parent = this.txt_Prenom;
            this.txt_Prenom.Size = new System.Drawing.Size(252, 36);
            this.txt_Prenom.TabIndex = 7;
            // 
            // txt_Nom
            // 
            this.txt_Nom.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_Nom.Animated = true;
            this.txt_Nom.BorderRadius = 15;
            this.txt_Nom.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_Nom.DefaultText = "";
            this.txt_Nom.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_Nom.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_Nom.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Nom.DisabledState.Parent = this.txt_Nom;
            this.txt_Nom.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Nom.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Nom.FocusedState.Parent = this.txt_Nom;
            this.txt_Nom.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txt_Nom.ForeColor = System.Drawing.Color.Blue;
            this.txt_Nom.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.txt_Nom.HoverState.Parent = this.txt_Nom;
            this.txt_Nom.Location = new System.Drawing.Point(41, 153);
            this.txt_Nom.Name = "txt_Nom";
            this.txt_Nom.PasswordChar = '\0';
            this.txt_Nom.PlaceholderForeColor = System.Drawing.Color.CornflowerBlue;
            this.txt_Nom.PlaceholderText = "Saisir Le nom d\'élève";
            this.txt_Nom.SelectedText = "";
            this.txt_Nom.ShadowDecoration.Parent = this.txt_Nom;
            this.txt_Nom.Size = new System.Drawing.Size(252, 36);
            this.txt_Nom.TabIndex = 7;
            // 
            // guna2ShadowPanel2
            // 
            this.guna2ShadowPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ShadowPanel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel2.Controls.Add(this.label7);
            this.guna2ShadowPanel2.Controls.Add(this.txt_NomSearch);
            this.guna2ShadowPanel2.Controls.Add(this.DGV_Result);
            this.guna2ShadowPanel2.Controls.Add(this.cb_classe);
            this.guna2ShadowPanel2.Controls.Add(this.label8);
            this.guna2ShadowPanel2.FillColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel2.Location = new System.Drawing.Point(3, 344);
            this.guna2ShadowPanel2.Name = "guna2ShadowPanel2";
            this.guna2ShadowPanel2.ShadowColor = System.Drawing.Color.Black;
            this.guna2ShadowPanel2.ShadowShift = 12;
            this.guna2ShadowPanel2.Size = new System.Drawing.Size(868, 313);
            this.guna2ShadowPanel2.TabIndex = 14;
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(277, 19);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 17);
            this.label7.TabIndex = 17;
            this.label7.Text = "Nom :";
            // 
            // txt_NomSearch
            // 
            this.txt_NomSearch.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_NomSearch.Animated = true;
            this.txt_NomSearch.BorderRadius = 15;
            this.txt_NomSearch.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_NomSearch.DefaultText = "";
            this.txt_NomSearch.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_NomSearch.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_NomSearch.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_NomSearch.DisabledState.Parent = this.txt_NomSearch;
            this.txt_NomSearch.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_NomSearch.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_NomSearch.FocusedState.Parent = this.txt_NomSearch;
            this.txt_NomSearch.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txt_NomSearch.ForeColor = System.Drawing.Color.Blue;
            this.txt_NomSearch.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.txt_NomSearch.HoverState.Parent = this.txt_NomSearch;
            this.txt_NomSearch.Location = new System.Drawing.Point(280, 39);
            this.txt_NomSearch.Name = "txt_NomSearch";
            this.txt_NomSearch.PasswordChar = '\0';
            this.txt_NomSearch.PlaceholderForeColor = System.Drawing.Color.CornflowerBlue;
            this.txt_NomSearch.PlaceholderText = "Saisir Le nom d\'élève";
            this.txt_NomSearch.SelectedText = "";
            this.txt_NomSearch.ShadowDecoration.Parent = this.txt_NomSearch;
            this.txt_NomSearch.Size = new System.Drawing.Size(252, 36);
            this.txt_NomSearch.TabIndex = 16;
            // 
            // DGV_Result
            // 
            this.DGV_Result.AllowUserToAddRows = false;
            this.DGV_Result.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Empty;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Empty;
            this.DGV_Result.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.DGV_Result.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.DGV_Result.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DGV_Result.BackgroundColor = System.Drawing.Color.White;
            this.DGV_Result.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DGV_Result.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.DGV_Result.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGV_Result.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.DGV_Result.ColumnHeadersHeight = 4;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DGV_Result.DefaultCellStyle = dataGridViewCellStyle3;
            this.DGV_Result.EnableHeadersVisualStyles = false;
            this.DGV_Result.GridColor = System.Drawing.Color.Gray;
            this.DGV_Result.Location = new System.Drawing.Point(28, 99);
            this.DGV_Result.Name = "DGV_Result";
            this.DGV_Result.ReadOnly = true;
            this.DGV_Result.RowHeadersVisible = false;
            this.DGV_Result.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGV_Result.Size = new System.Drawing.Size(808, 188);
            this.DGV_Result.TabIndex = 15;
            this.DGV_Result.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.Default;
            this.DGV_Result.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.DGV_Result.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.DGV_Result.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.DGV_Result.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.DGV_Result.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.DGV_Result.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.DGV_Result.ThemeStyle.GridColor = System.Drawing.Color.Gray;
            this.DGV_Result.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.DGV_Result.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.DGV_Result.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DGV_Result.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.DGV_Result.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.DGV_Result.ThemeStyle.HeaderStyle.Height = 4;
            this.DGV_Result.ThemeStyle.ReadOnly = true;
            this.DGV_Result.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.DGV_Result.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.DGV_Result.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DGV_Result.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.DGV_Result.ThemeStyle.RowsStyle.Height = 22;
            this.DGV_Result.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.DGV_Result.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            // 
            // cb_classe
            // 
            this.cb_classe.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cb_classe.Animated = true;
            this.cb_classe.BackColor = System.Drawing.Color.Transparent;
            this.cb_classe.BorderRadius = 15;
            this.cb_classe.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cb_classe.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_classe.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cb_classe.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cb_classe.FocusedState.Parent = this.cb_classe;
            this.cb_classe.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cb_classe.ForeColor = System.Drawing.Color.Blue;
            this.cb_classe.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.cb_classe.HoverState.Parent = this.cb_classe;
            this.cb_classe.ItemHeight = 30;
            this.cb_classe.ItemsAppearance.Parent = this.cb_classe;
            this.cb_classe.Location = new System.Drawing.Point(28, 39);
            this.cb_classe.Name = "cb_classe";
            this.cb_classe.ShadowDecoration.Parent = this.cb_classe;
            this.cb_classe.Size = new System.Drawing.Size(246, 36);
            this.cb_classe.TabIndex = 12;
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(25, 21);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(73, 17);
            this.label8.TabIndex = 9;
            this.label8.Text = "La classe :";
            // 
            // Eleves
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = global::AppAbdelMoumen.Properties.Resources.IMG_20210419_WA0002;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(895, 656);
            this.Controls.Add(this.guna2ShadowPanel2);
            this.Controls.Add(this.guna2ShadowPanel3);
            this.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Eleves";
            this.Text = "Eleves";
            this.Load += new System.EventHandler(this.Eleves_Load);
            this.guna2ShadowPanel3.ResumeLayout(false);
            this.guna2ShadowPanel3.PerformLayout();
            this.guna2ShadowPanel2.ResumeLayout(false);
            this.guna2ShadowPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Result)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel3;
        private Guna.UI2.WinForms.Guna2ComboBox cb_AjtClasse;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label9;
        private Guna.UI2.WinForms.Guna2GradientButton bt_Imprimer;
        private Guna.UI2.WinForms.Guna2TextBox txt_Massar;
        private Guna.UI2.WinForms.Guna2TextBox txt_Prenom;
        private Guna.UI2.WinForms.Guna2TextBox txt_Nom;
        private Guna.UI2.WinForms.Guna2ComboBox cb_Niveau;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2GradientButton bt_Supprimer;
        private Guna.UI2.WinForms.Guna2GradientButton bt_Ajouter;
        private Guna.UI2.WinForms.Guna2GradientButton bt_Modifier;
        private Guna.UI2.WinForms.Guna2GradientButton bt_Reinitialiser;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel2;
        private Guna.UI2.WinForms.Guna2ComboBox cb_classe;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private Guna.UI2.WinForms.Guna2TextBox txt_Numero;
        private Guna.UI2.WinForms.Guna2DataGridView DGV_Result;
        private System.Windows.Forms.Label label7;
        private Guna.UI2.WinForms.Guna2TextBox txt_NomSearch;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lb_Mail;
    }
}