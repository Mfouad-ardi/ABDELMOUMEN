﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppAbdelMoumen
{
    public partial class Certificats : Form
    {
        public Certificats()
        {
            InitializeComponent();
        }

        private void DGV_Certificats_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
