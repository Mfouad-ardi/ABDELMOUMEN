﻿
namespace AppAbdelMoumen
{
    partial class Classes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.guna2ShadowPanel3 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.cb_filiere = new Guna.UI2.WinForms.Guna2ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.bt_Supprimer = new Guna.UI2.WinForms.Guna2GradientButton();
            this.bt_Ajouter = new Guna.UI2.WinForms.Guna2GradientButton();
            this.bt_Modifier = new Guna.UI2.WinForms.Guna2GradientButton();
            this.txt_Libelle = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2ShadowPanel1 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.guna2ShadowPanel2 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.DGV_Classes = new Guna.UI2.WinForms.Guna2DataGridView();
            this.nbr_eleve = new Guna.UI2.WinForms.Guna2NumericUpDown();
            this.guna2ShadowPanel3.SuspendLayout();
            this.guna2ShadowPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Classes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nbr_eleve)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2ShadowPanel3
            // 
            this.guna2ShadowPanel3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.guna2ShadowPanel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel3.Controls.Add(this.nbr_eleve);
            this.guna2ShadowPanel3.Controls.Add(this.cb_filiere);
            this.guna2ShadowPanel3.Controls.Add(this.label2);
            this.guna2ShadowPanel3.Controls.Add(this.label1);
            this.guna2ShadowPanel3.Controls.Add(this.label9);
            this.guna2ShadowPanel3.Controls.Add(this.bt_Supprimer);
            this.guna2ShadowPanel3.Controls.Add(this.bt_Ajouter);
            this.guna2ShadowPanel3.Controls.Add(this.bt_Modifier);
            this.guna2ShadowPanel3.Controls.Add(this.txt_Libelle);
            this.guna2ShadowPanel3.FillColor = System.Drawing.Color.Blue;
            this.guna2ShadowPanel3.Location = new System.Drawing.Point(23, 12);
            this.guna2ShadowPanel3.Name = "guna2ShadowPanel3";
            this.guna2ShadowPanel3.ShadowColor = System.Drawing.Color.Black;
            this.guna2ShadowPanel3.ShadowShift = 12;
            this.guna2ShadowPanel3.Size = new System.Drawing.Size(444, 341);
            this.guna2ShadowPanel3.TabIndex = 16;
            // 
            // cb_filiere
            // 
            this.cb_filiere.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cb_filiere.Animated = true;
            this.cb_filiere.BackColor = System.Drawing.Color.Transparent;
            this.cb_filiere.BorderRadius = 15;
            this.cb_filiere.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cb_filiere.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_filiere.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cb_filiere.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cb_filiere.FocusedState.Parent = this.cb_filiere;
            this.cb_filiere.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cb_filiere.ForeColor = System.Drawing.Color.Blue;
            this.cb_filiere.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.cb_filiere.HoverState.Parent = this.cb_filiere;
            this.cb_filiere.ItemHeight = 30;
            this.cb_filiere.ItemsAppearance.Parent = this.cb_filiere;
            this.cb_filiere.Location = new System.Drawing.Point(94, 194);
            this.cb_filiere.Name = "cb_filiere";
            this.cb_filiere.ShadowDecoration.Parent = this.cb_filiere;
            this.cb_filiere.Size = new System.Drawing.Size(249, 36);
            this.cb_filiere.TabIndex = 17;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(91, 174);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 17);
            this.label2.TabIndex = 16;
            this.label2.Text = "Filiére :";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(90, 94);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 17);
            this.label1.TabIndex = 9;
            this.label1.Text = "Nombre des élèves";
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(91, 24);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(56, 17);
            this.label9.TabIndex = 9;
            this.label9.Text = "Libelle :";
            // 
            // bt_Supprimer
            // 
            this.bt_Supprimer.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bt_Supprimer.BorderRadius = 20;
            this.bt_Supprimer.CheckedState.Parent = this.bt_Supprimer;
            this.bt_Supprimer.CustomImages.Parent = this.bt_Supprimer;
            this.bt_Supprimer.FillColor = System.Drawing.Color.Navy;
            this.bt_Supprimer.FillColor2 = System.Drawing.Color.DodgerBlue;
            this.bt_Supprimer.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bt_Supprimer.ForeColor = System.Drawing.Color.White;
            this.bt_Supprimer.HoverState.BorderColor = System.Drawing.Color.Black;
            this.bt_Supprimer.HoverState.FillColor = System.Drawing.Color.Navy;
            this.bt_Supprimer.HoverState.FillColor2 = System.Drawing.Color.Navy;
            this.bt_Supprimer.HoverState.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bt_Supprimer.HoverState.ForeColor = System.Drawing.Color.White;
            this.bt_Supprimer.HoverState.Parent = this.bt_Supprimer;
            this.bt_Supprimer.Location = new System.Drawing.Point(303, 268);
            this.bt_Supprimer.Name = "bt_Supprimer";
            this.bt_Supprimer.ShadowDecoration.Parent = this.bt_Supprimer;
            this.bt_Supprimer.Size = new System.Drawing.Size(118, 39);
            this.bt_Supprimer.TabIndex = 8;
            this.bt_Supprimer.Text = "Supprimer";
            // 
            // bt_Ajouter
            // 
            this.bt_Ajouter.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bt_Ajouter.BorderRadius = 20;
            this.bt_Ajouter.CheckedState.Parent = this.bt_Ajouter;
            this.bt_Ajouter.CustomImages.Parent = this.bt_Ajouter;
            this.bt_Ajouter.FillColor = System.Drawing.Color.Navy;
            this.bt_Ajouter.FillColor2 = System.Drawing.Color.DodgerBlue;
            this.bt_Ajouter.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bt_Ajouter.ForeColor = System.Drawing.Color.White;
            this.bt_Ajouter.HoverState.BorderColor = System.Drawing.Color.Black;
            this.bt_Ajouter.HoverState.FillColor = System.Drawing.Color.Navy;
            this.bt_Ajouter.HoverState.FillColor2 = System.Drawing.Color.Navy;
            this.bt_Ajouter.HoverState.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bt_Ajouter.HoverState.ForeColor = System.Drawing.Color.White;
            this.bt_Ajouter.HoverState.Parent = this.bt_Ajouter;
            this.bt_Ajouter.Location = new System.Drawing.Point(28, 268);
            this.bt_Ajouter.Name = "bt_Ajouter";
            this.bt_Ajouter.ShadowDecoration.Parent = this.bt_Ajouter;
            this.bt_Ajouter.Size = new System.Drawing.Size(118, 39);
            this.bt_Ajouter.TabIndex = 8;
            this.bt_Ajouter.Text = "Ajouter";
            // 
            // bt_Modifier
            // 
            this.bt_Modifier.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bt_Modifier.BorderRadius = 20;
            this.bt_Modifier.CheckedState.Parent = this.bt_Modifier;
            this.bt_Modifier.CustomImages.Parent = this.bt_Modifier;
            this.bt_Modifier.FillColor = System.Drawing.Color.Navy;
            this.bt_Modifier.FillColor2 = System.Drawing.Color.DodgerBlue;
            this.bt_Modifier.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bt_Modifier.ForeColor = System.Drawing.Color.White;
            this.bt_Modifier.HoverState.BorderColor = System.Drawing.Color.Black;
            this.bt_Modifier.HoverState.FillColor = System.Drawing.Color.Navy;
            this.bt_Modifier.HoverState.FillColor2 = System.Drawing.Color.Navy;
            this.bt_Modifier.HoverState.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bt_Modifier.HoverState.ForeColor = System.Drawing.Color.White;
            this.bt_Modifier.HoverState.Parent = this.bt_Modifier;
            this.bt_Modifier.Location = new System.Drawing.Point(164, 268);
            this.bt_Modifier.Name = "bt_Modifier";
            this.bt_Modifier.ShadowDecoration.Parent = this.bt_Modifier;
            this.bt_Modifier.Size = new System.Drawing.Size(118, 39);
            this.bt_Modifier.TabIndex = 8;
            this.bt_Modifier.Text = "Modifier";
            // 
            // txt_Libelle
            // 
            this.txt_Libelle.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_Libelle.Animated = true;
            this.txt_Libelle.BorderRadius = 15;
            this.txt_Libelle.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_Libelle.DefaultText = "";
            this.txt_Libelle.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_Libelle.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_Libelle.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Libelle.DisabledState.Parent = this.txt_Libelle;
            this.txt_Libelle.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Libelle.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Libelle.FocusedState.Parent = this.txt_Libelle;
            this.txt_Libelle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txt_Libelle.ForeColor = System.Drawing.Color.Blue;
            this.txt_Libelle.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.txt_Libelle.HoverState.Parent = this.txt_Libelle;
            this.txt_Libelle.Location = new System.Drawing.Point(91, 51);
            this.txt_Libelle.Name = "txt_Libelle";
            this.txt_Libelle.PasswordChar = '\0';
            this.txt_Libelle.PlaceholderForeColor = System.Drawing.Color.CornflowerBlue;
            this.txt_Libelle.PlaceholderText = "Saisir la Classe";
            this.txt_Libelle.SelectedText = "";
            this.txt_Libelle.ShadowDecoration.Parent = this.txt_Libelle;
            this.txt_Libelle.Size = new System.Drawing.Size(252, 36);
            this.txt_Libelle.TabIndex = 7;
            // 
            // guna2ShadowPanel1
            // 
            this.guna2ShadowPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.guna2ShadowPanel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel1.FillColor = System.Drawing.Color.Blue;
            this.guna2ShadowPanel1.Location = new System.Drawing.Point(23, 377);
            this.guna2ShadowPanel1.Name = "guna2ShadowPanel1";
            this.guna2ShadowPanel1.ShadowColor = System.Drawing.Color.Black;
            this.guna2ShadowPanel1.ShadowShift = 12;
            this.guna2ShadowPanel1.Size = new System.Drawing.Size(444, 292);
            this.guna2ShadowPanel1.TabIndex = 20;
            // 
            // guna2ShadowPanel2
            // 
            this.guna2ShadowPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ShadowPanel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel2.Controls.Add(this.DGV_Classes);
            this.guna2ShadowPanel2.FillColor = System.Drawing.Color.Blue;
            this.guna2ShadowPanel2.Location = new System.Drawing.Point(462, 12);
            this.guna2ShadowPanel2.Name = "guna2ShadowPanel2";
            this.guna2ShadowPanel2.ShadowColor = System.Drawing.Color.Black;
            this.guna2ShadowPanel2.ShadowShift = 12;
            this.guna2ShadowPanel2.Size = new System.Drawing.Size(454, 657);
            this.guna2ShadowPanel2.TabIndex = 19;
            // 
            // DGV_Classes
            // 
            this.DGV_Classes.AllowUserToAddRows = false;
            this.DGV_Classes.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.DGV_Classes.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.DGV_Classes.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DGV_Classes.BackgroundColor = System.Drawing.Color.White;
            this.DGV_Classes.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DGV_Classes.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.DGV_Classes.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGV_Classes.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.DGV_Classes.ColumnHeadersHeight = 4;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DGV_Classes.DefaultCellStyle = dataGridViewCellStyle3;
            this.DGV_Classes.EnableHeadersVisualStyles = false;
            this.DGV_Classes.GridColor = System.Drawing.Color.Gray;
            this.DGV_Classes.Location = new System.Drawing.Point(23, 51);
            this.DGV_Classes.Name = "DGV_Classes";
            this.DGV_Classes.ReadOnly = true;
            this.DGV_Classes.RowHeadersVisible = false;
            this.DGV_Classes.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGV_Classes.Size = new System.Drawing.Size(410, 552);
            this.DGV_Classes.TabIndex = 15;
            this.DGV_Classes.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.Default;
            this.DGV_Classes.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.DGV_Classes.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.DGV_Classes.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.DGV_Classes.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.DGV_Classes.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.DGV_Classes.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.DGV_Classes.ThemeStyle.GridColor = System.Drawing.Color.Gray;
            this.DGV_Classes.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.DGV_Classes.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.DGV_Classes.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DGV_Classes.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.DGV_Classes.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.DGV_Classes.ThemeStyle.HeaderStyle.Height = 4;
            this.DGV_Classes.ThemeStyle.ReadOnly = true;
            this.DGV_Classes.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.DGV_Classes.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.DGV_Classes.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DGV_Classes.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.DGV_Classes.ThemeStyle.RowsStyle.Height = 22;
            this.DGV_Classes.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.DGV_Classes.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            // 
            // nbr_eleve
            // 
            this.nbr_eleve.BackColor = System.Drawing.Color.Transparent;
            this.nbr_eleve.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.nbr_eleve.BorderRadius = 20;
            this.nbr_eleve.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.nbr_eleve.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.nbr_eleve.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.nbr_eleve.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.nbr_eleve.DisabledState.Parent = this.nbr_eleve;
            this.nbr_eleve.DisabledState.UpDownButtonFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(177)))), ((int)(((byte)(177)))), ((int)(((byte)(177)))));
            this.nbr_eleve.DisabledState.UpDownButtonForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(203)))), ((int)(((byte)(203)))), ((int)(((byte)(203)))));
            this.nbr_eleve.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.nbr_eleve.FocusedState.Parent = this.nbr_eleve;
            this.nbr_eleve.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.nbr_eleve.ForeColor = System.Drawing.Color.Blue;
            this.nbr_eleve.Location = new System.Drawing.Point(93, 129);
            this.nbr_eleve.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.nbr_eleve.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nbr_eleve.Name = "nbr_eleve";
            this.nbr_eleve.ShadowDecoration.Parent = this.nbr_eleve;
            this.nbr_eleve.Size = new System.Drawing.Size(250, 36);
            this.nbr_eleve.TabIndex = 18;
            this.nbr_eleve.UpDownButtonFillColor = System.Drawing.Color.Blue;
            this.nbr_eleve.UpDownButtonForeColor = System.Drawing.Color.White;
            this.nbr_eleve.Value = new decimal(new int[] {
            300,
            0,
            0,
            0});
            // 
            // Classes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(935, 681);
            this.Controls.Add(this.guna2ShadowPanel1);
            this.Controls.Add(this.guna2ShadowPanel2);
            this.Controls.Add(this.guna2ShadowPanel3);
            this.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Classes";
            this.Text = "Classes";
            this.guna2ShadowPanel3.ResumeLayout(false);
            this.guna2ShadowPanel3.PerformLayout();
            this.guna2ShadowPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Classes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nbr_eleve)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel3;
        private Guna.UI2.WinForms.Guna2ComboBox cb_filiere;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label9;
        private Guna.UI2.WinForms.Guna2GradientButton bt_Supprimer;
        private Guna.UI2.WinForms.Guna2GradientButton bt_Ajouter;
        private Guna.UI2.WinForms.Guna2GradientButton bt_Modifier;
        private Guna.UI2.WinForms.Guna2TextBox txt_Libelle;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel1;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel2;
        private Guna.UI2.WinForms.Guna2DataGridView DGV_Classes;
        private Guna.UI2.WinForms.Guna2NumericUpDown nbr_eleve;
    }
}