﻿
namespace AppAbdelMoumen
{
    partial class Filieres
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.guna2ShadowPanel2 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.DGV_Filiere = new Guna.UI2.WinForms.Guna2DataGridView();
            this.guna2ShadowPanel3 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_Libelle = new Guna.UI2.WinForms.Guna2TextBox();
            this.bt_Supprimer = new Guna.UI2.WinForms.Guna2GradientButton();
            this.bt_Ajouter = new Guna.UI2.WinForms.Guna2GradientButton();
            this.bt_Modifier = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2ShadowPanel1 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.guna2ShadowPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Filiere)).BeginInit();
            this.guna2ShadowPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2ShadowPanel2
            // 
            this.guna2ShadowPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ShadowPanel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel2.Controls.Add(this.DGV_Filiere);
            this.guna2ShadowPanel2.FillColor = System.Drawing.Color.Blue;
            this.guna2ShadowPanel2.Location = new System.Drawing.Point(405, 12);
            this.guna2ShadowPanel2.Name = "guna2ShadowPanel2";
            this.guna2ShadowPanel2.ShadowColor = System.Drawing.Color.Black;
            this.guna2ShadowPanel2.ShadowShift = 12;
            this.guna2ShadowPanel2.Size = new System.Drawing.Size(500, 657);
            this.guna2ShadowPanel2.TabIndex = 16;
            // 
            // DGV_Filiere
            // 
            this.DGV_Filiere.AllowUserToAddRows = false;
            this.DGV_Filiere.AllowUserToDeleteRows = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Empty;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.Empty;
            this.DGV_Filiere.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.DGV_Filiere.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DGV_Filiere.BackgroundColor = System.Drawing.Color.White;
            this.DGV_Filiere.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DGV_Filiere.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.DGV_Filiere.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGV_Filiere.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.DGV_Filiere.ColumnHeadersHeight = 4;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DGV_Filiere.DefaultCellStyle = dataGridViewCellStyle6;
            this.DGV_Filiere.EnableHeadersVisualStyles = false;
            this.DGV_Filiere.GridColor = System.Drawing.Color.Gray;
            this.DGV_Filiere.Location = new System.Drawing.Point(23, 51);
            this.DGV_Filiere.Name = "DGV_Filiere";
            this.DGV_Filiere.ReadOnly = true;
            this.DGV_Filiere.RowHeadersVisible = false;
            this.DGV_Filiere.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGV_Filiere.Size = new System.Drawing.Size(456, 552);
            this.DGV_Filiere.TabIndex = 15;
            this.DGV_Filiere.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.Default;
            this.DGV_Filiere.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.DGV_Filiere.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.DGV_Filiere.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.DGV_Filiere.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.DGV_Filiere.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.DGV_Filiere.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.DGV_Filiere.ThemeStyle.GridColor = System.Drawing.Color.Gray;
            this.DGV_Filiere.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.DGV_Filiere.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.DGV_Filiere.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DGV_Filiere.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.DGV_Filiere.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.DGV_Filiere.ThemeStyle.HeaderStyle.Height = 4;
            this.DGV_Filiere.ThemeStyle.ReadOnly = true;
            this.DGV_Filiere.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.DGV_Filiere.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.DGV_Filiere.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DGV_Filiere.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.DGV_Filiere.ThemeStyle.RowsStyle.Height = 22;
            this.DGV_Filiere.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.DGV_Filiere.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            // 
            // guna2ShadowPanel3
            // 
            this.guna2ShadowPanel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel3.Controls.Add(this.label6);
            this.guna2ShadowPanel3.Controls.Add(this.txt_Libelle);
            this.guna2ShadowPanel3.Controls.Add(this.bt_Supprimer);
            this.guna2ShadowPanel3.Controls.Add(this.bt_Ajouter);
            this.guna2ShadowPanel3.Controls.Add(this.bt_Modifier);
            this.guna2ShadowPanel3.FillColor = System.Drawing.Color.Blue;
            this.guna2ShadowPanel3.Location = new System.Drawing.Point(30, 12);
            this.guna2ShadowPanel3.Name = "guna2ShadowPanel3";
            this.guna2ShadowPanel3.ShadowColor = System.Drawing.Color.Black;
            this.guna2ShadowPanel3.ShadowShift = 12;
            this.guna2ShadowPanel3.Size = new System.Drawing.Size(352, 341);
            this.guna2ShadowPanel3.TabIndex = 15;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(47, 38);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 19);
            this.label6.TabIndex = 13;
            this.label6.Text = "Libelle :";
            // 
            // txt_Libelle
            // 
            this.txt_Libelle.Animated = true;
            this.txt_Libelle.BorderRadius = 15;
            this.txt_Libelle.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_Libelle.DefaultText = "";
            this.txt_Libelle.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_Libelle.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_Libelle.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Libelle.DisabledState.Parent = this.txt_Libelle;
            this.txt_Libelle.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Libelle.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Libelle.FocusedState.Parent = this.txt_Libelle;
            this.txt_Libelle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txt_Libelle.ForeColor = System.Drawing.Color.Blue;
            this.txt_Libelle.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.txt_Libelle.HoverState.Parent = this.txt_Libelle;
            this.txt_Libelle.Location = new System.Drawing.Point(41, 74);
            this.txt_Libelle.Name = "txt_Libelle";
            this.txt_Libelle.PasswordChar = '\0';
            this.txt_Libelle.PlaceholderForeColor = System.Drawing.Color.CornflowerBlue;
            this.txt_Libelle.PlaceholderText = "Saisir La filiére";
            this.txt_Libelle.SelectedText = "";
            this.txt_Libelle.ShadowDecoration.Parent = this.txt_Libelle;
            this.txt_Libelle.Size = new System.Drawing.Size(252, 36);
            this.txt_Libelle.TabIndex = 12;
            // 
            // bt_Supprimer
            // 
            this.bt_Supprimer.BorderRadius = 20;
            this.bt_Supprimer.CheckedState.Parent = this.bt_Supprimer;
            this.bt_Supprimer.CustomImages.Parent = this.bt_Supprimer;
            this.bt_Supprimer.FillColor = System.Drawing.Color.Navy;
            this.bt_Supprimer.FillColor2 = System.Drawing.Color.DodgerBlue;
            this.bt_Supprimer.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bt_Supprimer.ForeColor = System.Drawing.Color.White;
            this.bt_Supprimer.HoverState.BorderColor = System.Drawing.Color.Black;
            this.bt_Supprimer.HoverState.FillColor = System.Drawing.Color.Navy;
            this.bt_Supprimer.HoverState.FillColor2 = System.Drawing.Color.Navy;
            this.bt_Supprimer.HoverState.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bt_Supprimer.HoverState.ForeColor = System.Drawing.Color.White;
            this.bt_Supprimer.HoverState.Parent = this.bt_Supprimer;
            this.bt_Supprimer.Location = new System.Drawing.Point(31, 241);
            this.bt_Supprimer.Name = "bt_Supprimer";
            this.bt_Supprimer.ShadowDecoration.Parent = this.bt_Supprimer;
            this.bt_Supprimer.Size = new System.Drawing.Size(262, 39);
            this.bt_Supprimer.TabIndex = 8;
            this.bt_Supprimer.Text = "Supprimer";
            // 
            // bt_Ajouter
            // 
            this.bt_Ajouter.BorderRadius = 20;
            this.bt_Ajouter.CheckedState.Parent = this.bt_Ajouter;
            this.bt_Ajouter.CustomImages.Parent = this.bt_Ajouter;
            this.bt_Ajouter.FillColor = System.Drawing.Color.Navy;
            this.bt_Ajouter.FillColor2 = System.Drawing.Color.DodgerBlue;
            this.bt_Ajouter.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bt_Ajouter.ForeColor = System.Drawing.Color.White;
            this.bt_Ajouter.HoverState.BorderColor = System.Drawing.Color.Black;
            this.bt_Ajouter.HoverState.FillColor = System.Drawing.Color.Navy;
            this.bt_Ajouter.HoverState.FillColor2 = System.Drawing.Color.Navy;
            this.bt_Ajouter.HoverState.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bt_Ajouter.HoverState.ForeColor = System.Drawing.Color.White;
            this.bt_Ajouter.HoverState.Parent = this.bt_Ajouter;
            this.bt_Ajouter.Location = new System.Drawing.Point(31, 178);
            this.bt_Ajouter.Name = "bt_Ajouter";
            this.bt_Ajouter.ShadowDecoration.Parent = this.bt_Ajouter;
            this.bt_Ajouter.Size = new System.Drawing.Size(118, 39);
            this.bt_Ajouter.TabIndex = 8;
            this.bt_Ajouter.Text = "Ajouter";
            // 
            // bt_Modifier
            // 
            this.bt_Modifier.BorderRadius = 20;
            this.bt_Modifier.CheckedState.Parent = this.bt_Modifier;
            this.bt_Modifier.CustomImages.Parent = this.bt_Modifier;
            this.bt_Modifier.FillColor = System.Drawing.Color.Navy;
            this.bt_Modifier.FillColor2 = System.Drawing.Color.DodgerBlue;
            this.bt_Modifier.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bt_Modifier.ForeColor = System.Drawing.Color.White;
            this.bt_Modifier.HoverState.BorderColor = System.Drawing.Color.Black;
            this.bt_Modifier.HoverState.FillColor = System.Drawing.Color.Navy;
            this.bt_Modifier.HoverState.FillColor2 = System.Drawing.Color.Navy;
            this.bt_Modifier.HoverState.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bt_Modifier.HoverState.ForeColor = System.Drawing.Color.White;
            this.bt_Modifier.HoverState.Parent = this.bt_Modifier;
            this.bt_Modifier.Location = new System.Drawing.Point(175, 178);
            this.bt_Modifier.Name = "bt_Modifier";
            this.bt_Modifier.ShadowDecoration.Parent = this.bt_Modifier;
            this.bt_Modifier.Size = new System.Drawing.Size(118, 39);
            this.bt_Modifier.TabIndex = 8;
            this.bt_Modifier.Text = "Modifier";
            // 
            // guna2ShadowPanel1
            // 
            this.guna2ShadowPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.guna2ShadowPanel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel1.FillColor = System.Drawing.Color.Blue;
            this.guna2ShadowPanel1.Location = new System.Drawing.Point(30, 377);
            this.guna2ShadowPanel1.Name = "guna2ShadowPanel1";
            this.guna2ShadowPanel1.ShadowColor = System.Drawing.Color.Black;
            this.guna2ShadowPanel1.ShadowShift = 12;
            this.guna2ShadowPanel1.Size = new System.Drawing.Size(352, 292);
            this.guna2ShadowPanel1.TabIndex = 18;
            // 
            // Filieres
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(935, 681);
            this.Controls.Add(this.guna2ShadowPanel1);
            this.Controls.Add(this.guna2ShadowPanel2);
            this.Controls.Add(this.guna2ShadowPanel3);
            this.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Filieres";
            this.Text = "Filieres";
            this.guna2ShadowPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Filiere)).EndInit();
            this.guna2ShadowPanel3.ResumeLayout(false);
            this.guna2ShadowPanel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel2;
        private Guna.UI2.WinForms.Guna2DataGridView DGV_Filiere;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel3;
        private System.Windows.Forms.Label label6;
        private Guna.UI2.WinForms.Guna2TextBox txt_Libelle;
        private Guna.UI2.WinForms.Guna2GradientButton bt_Supprimer;
        private Guna.UI2.WinForms.Guna2GradientButton bt_Ajouter;
        private Guna.UI2.WinForms.Guna2GradientButton bt_Modifier;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel1;
    }
}