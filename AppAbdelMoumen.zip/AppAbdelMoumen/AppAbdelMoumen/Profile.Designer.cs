﻿
namespace AppAbdelMoumen
{
    partial class Profile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.guna2ShadowPanel1 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.lb_Mail = new System.Windows.Forms.Label();
            this.lb_Prenom = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lb_Nom = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.guna2CirclePictureBox1 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.guna2ShadowPanel2 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.bt_Modifier = new Guna.UI2.WinForms.Guna2GradientButton();
            this.txt_Prenom = new Guna.UI2.WinForms.Guna2TextBox();
            this.txt_Nom = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2ShadowPanel3 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.bt_Changer = new Guna.UI2.WinForms.Guna2GradientButton();
            this.txt_Rpassw = new Guna.UI2.WinForms.Guna2TextBox();
            this.txt_Npassw = new Guna.UI2.WinForms.Guna2TextBox();
            this.lb_Message = new System.Windows.Forms.Label();
            this.guna2ShadowPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox1)).BeginInit();
            this.guna2ShadowPanel2.SuspendLayout();
            this.guna2ShadowPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2ShadowPanel1
            // 
            this.guna2ShadowPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ShadowPanel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel1.Controls.Add(this.lb_Mail);
            this.guna2ShadowPanel1.Controls.Add(this.lb_Prenom);
            this.guna2ShadowPanel1.Controls.Add(this.label3);
            this.guna2ShadowPanel1.Controls.Add(this.lb_Nom);
            this.guna2ShadowPanel1.Controls.Add(this.label2);
            this.guna2ShadowPanel1.Controls.Add(this.label1);
            this.guna2ShadowPanel1.Controls.Add(this.guna2CirclePictureBox1);
            this.guna2ShadowPanel1.FillColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel1.Location = new System.Drawing.Point(530, 12);
            this.guna2ShadowPanel1.Name = "guna2ShadowPanel1";
            this.guna2ShadowPanel1.ShadowColor = System.Drawing.Color.Black;
            this.guna2ShadowPanel1.ShadowShift = 12;
            this.guna2ShadowPanel1.Size = new System.Drawing.Size(377, 359);
            this.guna2ShadowPanel1.TabIndex = 11;
            // 
            // lb_Mail
            // 
            this.lb_Mail.AutoSize = true;
            this.lb_Mail.Font = new System.Drawing.Font("Century Gothic", 10.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Mail.ForeColor = System.Drawing.Color.White;
            this.lb_Mail.Location = new System.Drawing.Point(101, 271);
            this.lb_Mail.Name = "lb_Mail";
            this.lb_Mail.Size = new System.Drawing.Size(261, 17);
            this.lb_Mail.TabIndex = 10;
            this.lb_Mail.Text = "RoguiAbdelaziz@Abdelmoumen.com";
            // 
            // lb_Prenom
            // 
            this.lb_Prenom.AutoSize = true;
            this.lb_Prenom.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Prenom.ForeColor = System.Drawing.Color.White;
            this.lb_Prenom.Location = new System.Drawing.Point(104, 219);
            this.lb_Prenom.Name = "lb_Prenom";
            this.lb_Prenom.Size = new System.Drawing.Size(85, 18);
            this.lb_Prenom.TabIndex = 8;
            this.lb_Prenom.Text = "ABDELAZIZ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(24, 269);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 20);
            this.label3.TabIndex = 11;
            this.label3.Text = "Courriel :";
            // 
            // lb_Nom
            // 
            this.lb_Nom.AutoSize = true;
            this.lb_Nom.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Nom.ForeColor = System.Drawing.Color.White;
            this.lb_Nom.Location = new System.Drawing.Point(105, 172);
            this.lb_Nom.Name = "lb_Nom";
            this.lb_Nom.Size = new System.Drawing.Size(57, 18);
            this.lb_Nom.TabIndex = 6;
            this.lb_Nom.Text = "ROGUI";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(24, 219);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 20);
            this.label2.TabIndex = 9;
            this.label2.Text = "Prénom :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(26, 171);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 20);
            this.label1.TabIndex = 7;
            this.label1.Text = "Nom :";
            // 
            // guna2CirclePictureBox1
            // 
            this.guna2CirclePictureBox1.Image = global::AppAbdelMoumen.Properties.Resources._2754578_128;
            this.guna2CirclePictureBox1.Location = new System.Drawing.Point(126, 25);
            this.guna2CirclePictureBox1.Name = "guna2CirclePictureBox1";
            this.guna2CirclePictureBox1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CirclePictureBox1.ShadowDecoration.Parent = this.guna2CirclePictureBox1;
            this.guna2CirclePictureBox1.Size = new System.Drawing.Size(104, 106);
            this.guna2CirclePictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2CirclePictureBox1.TabIndex = 5;
            this.guna2CirclePictureBox1.TabStop = false;
            this.guna2CirclePictureBox1.UseTransparentBackground = true;
            // 
            // guna2ShadowPanel2
            // 
            this.guna2ShadowPanel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel2.Controls.Add(this.label7);
            this.guna2ShadowPanel2.Controls.Add(this.label8);
            this.guna2ShadowPanel2.Controls.Add(this.bt_Modifier);
            this.guna2ShadowPanel2.Controls.Add(this.txt_Prenom);
            this.guna2ShadowPanel2.Controls.Add(this.txt_Nom);
            this.guna2ShadowPanel2.FillColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel2.Location = new System.Drawing.Point(40, 12);
            this.guna2ShadowPanel2.Name = "guna2ShadowPanel2";
            this.guna2ShadowPanel2.ShadowColor = System.Drawing.Color.Black;
            this.guna2ShadowPanel2.ShadowShift = 12;
            this.guna2ShadowPanel2.Size = new System.Drawing.Size(377, 359);
            this.guna2ShadowPanel2.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(60, 148);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(73, 20);
            this.label7.TabIndex = 15;
            this.label7.Text = "Prénom :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(60, 41);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(51, 20);
            this.label8.TabIndex = 14;
            this.label8.Text = "Nom :";
            // 
            // bt_Modifier
            // 
            this.bt_Modifier.BorderRadius = 20;
            this.bt_Modifier.CheckedState.Parent = this.bt_Modifier;
            this.bt_Modifier.CustomImages.Parent = this.bt_Modifier;
            this.bt_Modifier.FillColor = System.Drawing.Color.Navy;
            this.bt_Modifier.FillColor2 = System.Drawing.Color.DodgerBlue;
            this.bt_Modifier.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bt_Modifier.ForeColor = System.Drawing.Color.White;
            this.bt_Modifier.HoverState.BorderColor = System.Drawing.Color.Black;
            this.bt_Modifier.HoverState.FillColor = System.Drawing.Color.Navy;
            this.bt_Modifier.HoverState.FillColor2 = System.Drawing.Color.Navy;
            this.bt_Modifier.HoverState.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bt_Modifier.HoverState.ForeColor = System.Drawing.Color.White;
            this.bt_Modifier.HoverState.Parent = this.bt_Modifier;
            this.bt_Modifier.Location = new System.Drawing.Point(64, 278);
            this.bt_Modifier.Name = "bt_Modifier";
            this.bt_Modifier.ShadowDecoration.Parent = this.bt_Modifier;
            this.bt_Modifier.Size = new System.Drawing.Size(118, 39);
            this.bt_Modifier.TabIndex = 13;
            this.bt_Modifier.Text = "Modifier";
            this.bt_Modifier.Click += new System.EventHandler(this.bt_Modifier_Click);
            // 
            // txt_Prenom
            // 
            this.txt_Prenom.Animated = true;
            this.txt_Prenom.BorderRadius = 15;
            this.txt_Prenom.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_Prenom.DefaultText = "";
            this.txt_Prenom.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_Prenom.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_Prenom.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Prenom.DisabledState.Parent = this.txt_Prenom;
            this.txt_Prenom.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Prenom.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Prenom.FocusedState.Parent = this.txt_Prenom;
            this.txt_Prenom.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txt_Prenom.ForeColor = System.Drawing.Color.Blue;
            this.txt_Prenom.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.txt_Prenom.HoverState.Parent = this.txt_Prenom;
            this.txt_Prenom.Location = new System.Drawing.Point(64, 175);
            this.txt_Prenom.Name = "txt_Prenom";
            this.txt_Prenom.PasswordChar = '\0';
            this.txt_Prenom.PlaceholderForeColor = System.Drawing.Color.CornflowerBlue;
            this.txt_Prenom.PlaceholderText = "Saisir Nouveau Prénom";
            this.txt_Prenom.SelectedText = "";
            this.txt_Prenom.ShadowDecoration.Parent = this.txt_Prenom;
            this.txt_Prenom.Size = new System.Drawing.Size(252, 36);
            this.txt_Prenom.TabIndex = 11;
            // 
            // txt_Nom
            // 
            this.txt_Nom.Animated = true;
            this.txt_Nom.BorderRadius = 15;
            this.txt_Nom.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_Nom.DefaultText = "";
            this.txt_Nom.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_Nom.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_Nom.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Nom.DisabledState.Parent = this.txt_Nom;
            this.txt_Nom.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Nom.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Nom.FocusedState.Parent = this.txt_Nom;
            this.txt_Nom.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txt_Nom.ForeColor = System.Drawing.Color.Blue;
            this.txt_Nom.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.txt_Nom.HoverState.Parent = this.txt_Nom;
            this.txt_Nom.Location = new System.Drawing.Point(64, 68);
            this.txt_Nom.Name = "txt_Nom";
            this.txt_Nom.PasswordChar = '\0';
            this.txt_Nom.PlaceholderForeColor = System.Drawing.Color.CornflowerBlue;
            this.txt_Nom.PlaceholderText = "Saisir Nouveau Nom";
            this.txt_Nom.SelectedText = "";
            this.txt_Nom.ShadowDecoration.Parent = this.txt_Nom;
            this.txt_Nom.Size = new System.Drawing.Size(252, 36);
            this.txt_Nom.TabIndex = 12;
            // 
            // guna2ShadowPanel3
            // 
            this.guna2ShadowPanel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ShadowPanel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel3.Controls.Add(this.lb_Message);
            this.guna2ShadowPanel3.Controls.Add(this.label10);
            this.guna2ShadowPanel3.Controls.Add(this.label9);
            this.guna2ShadowPanel3.Controls.Add(this.bt_Changer);
            this.guna2ShadowPanel3.Controls.Add(this.txt_Rpassw);
            this.guna2ShadowPanel3.Controls.Add(this.txt_Npassw);
            this.guna2ShadowPanel3.FillColor = System.Drawing.Color.Transparent;
            this.guna2ShadowPanel3.Location = new System.Drawing.Point(40, 456);
            this.guna2ShadowPanel3.Name = "guna2ShadowPanel3";
            this.guna2ShadowPanel3.ShadowColor = System.Drawing.Color.Black;
            this.guna2ShadowPanel3.ShadowShift = 12;
            this.guna2ShadowPanel3.Size = new System.Drawing.Size(867, 194);
            this.guna2ShadowPanel3.TabIndex = 11;
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(457, 38);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(194, 20);
            this.label10.TabIndex = 10;
            this.label10.Text = "Réécrire Le mot de passe";
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(125, 38);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(187, 20);
            this.label9.TabIndex = 9;
            this.label9.Text = "Nouvelle Mot de passe :";
            // 
            // bt_Changer
            // 
            this.bt_Changer.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bt_Changer.BorderRadius = 20;
            this.bt_Changer.CheckedState.Parent = this.bt_Changer;
            this.bt_Changer.CustomImages.Parent = this.bt_Changer;
            this.bt_Changer.FillColor = System.Drawing.Color.Navy;
            this.bt_Changer.FillColor2 = System.Drawing.Color.DodgerBlue;
            this.bt_Changer.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bt_Changer.ForeColor = System.Drawing.Color.White;
            this.bt_Changer.HoverState.BorderColor = System.Drawing.Color.Black;
            this.bt_Changer.HoverState.FillColor = System.Drawing.Color.Navy;
            this.bt_Changer.HoverState.FillColor2 = System.Drawing.Color.Navy;
            this.bt_Changer.HoverState.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bt_Changer.HoverState.ForeColor = System.Drawing.Color.White;
            this.bt_Changer.HoverState.Parent = this.bt_Changer;
            this.bt_Changer.Location = new System.Drawing.Point(595, 121);
            this.bt_Changer.Name = "bt_Changer";
            this.bt_Changer.ShadowDecoration.Parent = this.bt_Changer;
            this.bt_Changer.Size = new System.Drawing.Size(118, 39);
            this.bt_Changer.TabIndex = 8;
            this.bt_Changer.Text = "Changer";
            this.bt_Changer.Click += new System.EventHandler(this.bt_Changer_Click);
            // 
            // txt_Rpassw
            // 
            this.txt_Rpassw.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_Rpassw.Animated = true;
            this.txt_Rpassw.BorderRadius = 15;
            this.txt_Rpassw.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_Rpassw.DefaultText = "";
            this.txt_Rpassw.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_Rpassw.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_Rpassw.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Rpassw.DisabledState.Parent = this.txt_Rpassw;
            this.txt_Rpassw.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Rpassw.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Rpassw.FocusedState.Parent = this.txt_Rpassw;
            this.txt_Rpassw.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txt_Rpassw.ForeColor = System.Drawing.Color.Blue;
            this.txt_Rpassw.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.txt_Rpassw.HoverState.Parent = this.txt_Rpassw;
            this.txt_Rpassw.Location = new System.Drawing.Point(461, 65);
            this.txt_Rpassw.Name = "txt_Rpassw";
            this.txt_Rpassw.PasswordChar = '\0';
            this.txt_Rpassw.PlaceholderForeColor = System.Drawing.Color.CornflowerBlue;
            this.txt_Rpassw.PlaceholderText = "Réécrire Le Mot de passe";
            this.txt_Rpassw.SelectedText = "";
            this.txt_Rpassw.ShadowDecoration.Parent = this.txt_Rpassw;
            this.txt_Rpassw.Size = new System.Drawing.Size(252, 36);
            this.txt_Rpassw.TabIndex = 6;
            // 
            // txt_Npassw
            // 
            this.txt_Npassw.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txt_Npassw.Animated = true;
            this.txt_Npassw.BorderRadius = 15;
            this.txt_Npassw.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_Npassw.DefaultText = "";
            this.txt_Npassw.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_Npassw.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_Npassw.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Npassw.DisabledState.Parent = this.txt_Npassw;
            this.txt_Npassw.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_Npassw.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_Npassw.FocusedState.Parent = this.txt_Npassw;
            this.txt_Npassw.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txt_Npassw.ForeColor = System.Drawing.Color.Blue;
            this.txt_Npassw.HoverState.BorderColor = System.Drawing.Color.Lime;
            this.txt_Npassw.HoverState.Parent = this.txt_Npassw;
            this.txt_Npassw.Location = new System.Drawing.Point(129, 65);
            this.txt_Npassw.Name = "txt_Npassw";
            this.txt_Npassw.PasswordChar = '\0';
            this.txt_Npassw.PlaceholderForeColor = System.Drawing.Color.CornflowerBlue;
            this.txt_Npassw.PlaceholderText = "Saisir Nouveau Mot de passe";
            this.txt_Npassw.SelectedText = "";
            this.txt_Npassw.ShadowDecoration.Parent = this.txt_Npassw;
            this.txt_Npassw.Size = new System.Drawing.Size(252, 36);
            this.txt_Npassw.TabIndex = 7;
            // 
            // lb_Message
            // 
            this.lb_Message.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lb_Message.AutoSize = true;
            this.lb_Message.Font = new System.Drawing.Font("Century Gothic", 10.25F);
            this.lb_Message.ForeColor = System.Drawing.Color.Red;
            this.lb_Message.Location = new System.Drawing.Point(146, 104);
            this.lb_Message.Name = "lb_Message";
            this.lb_Message.Size = new System.Drawing.Size(0, 19);
            this.lb_Message.TabIndex = 11;
            // 
            // Profile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = global::AppAbdelMoumen.Properties.Resources.IMG_20210419_WA0002;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(935, 681);
            this.Controls.Add(this.guna2ShadowPanel3);
            this.Controls.Add(this.guna2ShadowPanel2);
            this.Controls.Add(this.guna2ShadowPanel1);
            this.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Profile";
            this.Text = "Profile";
            this.Load += new System.EventHandler(this.Profile_Load);
            this.guna2ShadowPanel1.ResumeLayout(false);
            this.guna2ShadowPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox1)).EndInit();
            this.guna2ShadowPanel2.ResumeLayout(false);
            this.guna2ShadowPanel2.PerformLayout();
            this.guna2ShadowPanel3.ResumeLayout(false);
            this.guna2ShadowPanel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private Guna.UI2.WinForms.Guna2GradientButton bt_Changer;
        private Guna.UI2.WinForms.Guna2TextBox txt_Rpassw;
        private Guna.UI2.WinForms.Guna2TextBox txt_Npassw;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private Guna.UI2.WinForms.Guna2GradientButton bt_Modifier;
        private Guna.UI2.WinForms.Guna2TextBox txt_Prenom;
        private Guna.UI2.WinForms.Guna2TextBox txt_Nom;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel1;
        private System.Windows.Forms.Label lb_Mail;
        private System.Windows.Forms.Label lb_Prenom;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lb_Nom;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox1;
        private System.Windows.Forms.Label lb_Message;
    }
}